const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { Storage } = require('@google-cloud/storage');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const ses = new AWS.SES({
    region: process.env.REGION
});
const dynamoDB = new AWS.DynamoDB.DocumentClient({
    region: process.env.REGION
});
const secretsManager = new AWS.SecretsManager({
    region: process.env.REGION
});

async function downloadReleaseFromGitHub(githubRepoUrl, fileName) {
    try {
        const assetResponse = await axios.get(githubRepoUrl, {
            responseType: 'arraybuffer',
        });
        console.error("---------- filename ------------");
        console.error(fileName);
        const filePath = path.join('/tmp', `${fileName}.zip`);
        console.error("---------- filepath ------------");
        console.error(filePath);
        fs.writeFileSync(filePath, assetResponse.data);

        console.log('Asset downloaded and stored:', githubRepoUrl);
        // return 'tempAsset.zip';

    } catch (error) {
        console.error(githubRepoUrl);
        console.error('Error downloading release from GitHub:', error);
        throw new Error('Error downloading release from GitHub');
    }
}

async function storeInGoogleCloudStorage(fileName) {
    // const privateKey = process.env.SERVICE_CREDS;
    // console.error(process.env.SERVICE_CREDS);
    // const decodedCredentials = Buffer.from(privateKey, 'base64').toString('utf-8');
    // const [email, key] = decodedCredentials.split(':');
    // console.error(email);
    // console.error(key);

    // let secretValue = await secretsManager.getSecretValue({ SecretId: process.env.SECRET_ARN }).promise();
    // console.error(secretValue.SecretString);
    // const key = Buffer.from(secretValue.SecretString, 'base64').toString('utf-8');
    // console.error(`-----BEGIN PRIVATE KEY-----\n${key}\n-----END PRIVATE KEY-----\n`);
    // const decodedKey = Buffer.from(secretValue.SecretString, 'base64').toString('utf-8');
    // console.error(decodedKey);
    let keyJson = Buffer.from(process.env.ACCESS_KEY, 'base64').toString();
    let key = JSON.parse(keyJson)['private_key'];
    // const key = `-----BEGIN PRIVATE KEY-----\n${secretValue.SecretString}\n-----END PRIVATE KEY-----\n`
    console.error(key);
    const storage = new Storage({
        projectId: process.env.PROJECT_ID,
        // credentials: secretValue.SecretString
        credentials: {
            client_email: process.env.SERVICE_EMAIL,
            private_key: key
        },
    });

    const bucketName = process.env.BUCKET_NAME;
    const filePath = `/tmp/${fileName}.zip`;
    const destinationFolder = 'assignments';

    try {
        await storage.bucket(bucketName).upload(filePath, {
            destination: `${destinationFolder}/${fileName}.zip`,
        });
        console.log('File uploaded to GCS successfully.');
    } catch (error) {
        console.error('Error uploading to GCS:', error);
        throw error;
    }
}

async function sendStatusEmail(userEmail, status) {
    const params = {
        Destination: { ToAddresses: [userEmail] },
        Message: {
            Body: { Text: { Data: `Download status: ${status}` } },
            Subject: { Data: 'Download Status' },
        },
        Source: 'no-reply@demo.saiveerendra-prathipati.me',
    };

    try {
        await ses.sendEmail(params).promise();
    } catch (error) {
        // throw new Error('Error sending status email');
        throw error;
    }
}

async function trackSentEmails(userEmail, status, githubRepoUrl) {
    const newUUID = uuidv4();
    const params = {
        TableName: process.env.DYNAMODB_TABLE,
        Item: {
            id: newUUID,
            userEmail: userEmail,
            timestamp: new Date().toISOString(),
            status: status,
            submissionURL: githubRepoUrl
        },
    };

    try {
        await dynamoDB.put(params).promise();
    } catch (error) {
        // throw new Error('Error tracking sent emails in DynamoDB');
        throw error;
    }
}

exports.handler = async (event) => {
    const snsMessage = JSON.parse(event.Records[0].Sns.Message);
    // const githubRepoUrl = "https://github.com/tparikh/myrepo/archive/refs/tags/v1.0.0.zip";
    // const userEmail = "prathipati.s@northeastern.edu";
    const githubRepoUrl = snsMessage.submissionUrl;
    const userEmail = snsMessage.user_id;
    const fileName = snsMessage.fileName;
    // console.error(event.Records[0].Sns);
    // console.error(event.Records[0].Sns.Message);
    console.error(githubRepoUrl);
    console.error(userEmail);
    console.error(fileName);

    try {
        await downloadReleaseFromGitHub(githubRepoUrl, fileName);
        
        await storeInGoogleCloudStorage(fileName);
        // await sendStatusEmail(userEmail, 'Download successful');
        // await trackSentEmails(userEmail, 'Download successful', githubRepoUrl);
    } catch (error) {
        console.error('Error:', error);
        // await sendStatusEmail(userEmail, 'Download failed');
        // await trackSentEmails(userEmail, 'Download failed', githubRepoUrl);
    }
};
